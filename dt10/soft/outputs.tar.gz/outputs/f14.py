def main():
	if(1):
		if(2):
			return 10
	return 11

# Boilerplate
if __name__ == "__main__":
	import sys
	ret=main()
	sys.exit(ret)
