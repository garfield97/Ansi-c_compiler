def main():
	z=0
	z=7
	return z

# Boilerplate
if __name__ == "__main__":
	import sys
	ret=main()
	sys.exit(ret)
