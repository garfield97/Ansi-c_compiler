def main():
	x=0
	x=5
	x=x*x
	return x

# Boilerplate
if __name__ == "__main__":
	import sys
	ret=main()
	sys.exit(ret)
