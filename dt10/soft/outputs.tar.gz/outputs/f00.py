def main():
	return 10

# Boilerplate
if __name__ == "__main__":
	import sys
	ret=main()
	sys.exit(ret)
