def main():
	if(0):
		return 10
	return 11

# Boilerplate
if __name__ == "__main__":
	import sys
	ret=main()
	sys.exit(ret)
